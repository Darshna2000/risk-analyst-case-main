# Risk-analyst-case
Risk Analyst case for a former job application

Please refer to the "Solution description.md"
